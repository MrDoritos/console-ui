#include "element.h"
/*
element::element(screen* scr)
	:framebuffer(scr)
{
	this->screen = scr;
}
	*/
void element::update() {
	for (auto* e : children)
		e->update();
	handler.handle(FLG_UPDATE);
}

void element::keypress() { 
	for (auto* e : children)
		e->keypress();
	handler.handle(FLG_KEYPRESS);	
}

void element::keyheld() {
	for (auto* e : children)
		e->keyheld();
	handler.handle(FLG_KEYHELD);
}

void element::keyrelease() {
	for (auto* e : children)
		e->keyrelease();
	handler.handle(FLG_KEYRELEASE);
}

void element::create() {
	for (auto* e : children)
		e->create();
	handler.handle(FLG_CREATE);
}

void element::resize() {
	for (auto* e : children)
		e->resize();
	handler.handle(FLG_RESIZE);
}

void element::onFrame() {
	frame();
	for (auto* e : children) {
		e->onFrame();
	}
	handler.handle(FLG_FRAME);
}

void element::onClear() {
	clear();
	for (auto* e : children) {
		e->onClear();
	}
	handler.handle(FLG_CLEAR);
}

void element::close() {
	for (auto* e : children)
		e->close();
	handler.handle(FLG_CLOSE);
}

void element::focus() {
	//Must not call children when focused, focus is a single element type deal, ya know
	//for (auto* e : children)
	//	e->focus();
	focused = true;
	handler.handle(FLG_FOCUS);
}

void element::add(element* element) {
	children.push_back(element);
}