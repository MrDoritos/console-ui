#pragma once

struct box {
	box(int offsetx, int offsety, int sizex, int sizey);
	box();
	void clip(int& x, int &y) {
		x = x >= sizex ? sizex - 1 : x;
		y = y >= sizey ? sizey - 1 : y;
		x = x < 0 ? 0 : x;
		y = y < 0 ? 0 : y;
	}
	
	int get(int x, int y) {
		return (y * sizex) + x;
	}
	int getCount() {
		return sizex * sizey;		
	}
	
	int sizex;
	int sizey;
	int offsetx;
	int offsety;
};