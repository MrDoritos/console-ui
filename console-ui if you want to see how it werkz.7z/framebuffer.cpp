#include "framebuffer.h"

#include "screen.h"

framebuffer::framebuffer(screen* screen)
{
	//int x = screen->getSizeX();
	scr = screen;
	backgroundcharacter = ' ';
	backgroundcolor = BBLACK | FWHITE;
	useScreen = false;
	useBackground = false;
}

int framebuffer::getSizeX() {
	return sizex;
}

void framebuffer::setBackground(char character, char color) {
	useBackground = true;
	backgroundcharacter = character;
	backgroundcolor = color;
}

void framebuffer::doUseScreen(bool uS) {
	if (uS) {
		
	} else {
		allocate(sizex, sizey);
	}
	useScreen = uS;
}

void framebuffer::doUseBackground(bool uB) {
	useBackground = uB;
}

void framebuffer::setSizeX(int sizex) {
	if (this->sizex == sizex)
		return;
	this->sizex = sizex;
	if (!useScreen)		
		allocate(sizex, sizey);
}

void framebuffer::setSizeY(int sizey) {
	if (this->sizey == sizey)
		return;
	this->sizey = sizey;
	if (!useScreen)		
		allocate(sizex, sizey);
}

void framebuffer::setSize(int sizex, int sizey) {
	if (this->sizey == sizey && this->sizex == sizex)
		return;
	this->sizey = sizey;
	this->sizex = sizex;
	if (!useScreen)
		allocate(sizex, sizey);
}

void framebuffer::setOffset(int offsetx, int offsety) {
	this->offsetx = offsetx;
	this->offsety = offsety;
}

void framebuffer::allocate(int sizex, int sizey) {
	fb = new char[sizex * sizey];
	cb = new char[sizex * sizey];
}

void framebuffer::frame() {
	//We don't need to copy if we already use the screen's buffer
	if (!useScreen) {
		for (int x = 0; x < sizex; x++)
			for (int y = 0; y < sizey; y++)
				write(x, y, fb[get(x, y)], cb[get(x, y)]);
	}
}

void framebuffer::clear() {
	if (useBackground)
			clear(backgroundcharacter, backgroundcolor);
	else 
		if (useNull)
			clear('\0', backgroundcolor);
		else
			clear(' ', backgroundcolor);
}

void framebuffer::clear(char character, char color) {
	for (int x = 0; x < sizex; x++)
		for (int y = 0; y < sizey; y++)
			write(x, y, character, color);
}	

void framebuffer::write(int x, int y, char character, char color) {
	if (useScreen) {
		scr->clip(x, y);
		scr->write(x, y, character, color);
	} else {
		fb[get(x, y)] = character;
		cb[get(x, y)] = color;
	}
}