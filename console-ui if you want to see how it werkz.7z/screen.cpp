#include "screen.h"
#include "element.h"

#include <string.h>

screen::screen()
	:framebuffer(this)
{
	child = new element(this);
	focused = child;
	setSize(console::getConsoleWidth(), console::getConsoleHeight());
	setBackground('/', BWHITE | FBLACK);
	clear();
	//Already know the screen resolution, and this will not change because the console buffer will remain the same.

}
	
void screen::start() {
	memset(keys, 0, sizeof(keys));
	loop();
}

void screen::focusPush(element* current, bool& token) {
	if (token) {
		focused = current;
		return;
	}
	//if ()
}

//Reverse iterator, however you do dat
void screen::focusPop(element* current, bool& token) {
	
}
	
void screen::loop() {
	while (true) {
		//Key presses
		char key = console::readKeyAsync();
		if (key == 27) {
			return;
		}			
		//Skip null key, null is no key
		for (int i = 1; i < 256; i++) {
			if (i == key) {
				if (keys[i].pressed = (!keys[i].held)) {
					pressed = i;
					child->keypress();
				}
				if (keys[i].held = (keys[i].pressed && !keys[i].held)) {
					keys[i].pressed = false;
					held = i;
					child->keyheld();
				}
			} else {
				if (keys[i].released = (keys[i].pressed || keys[i].held)) {
					keys[i].pressed = false;
					keys[i].held = false;
					released = i;
					child->keyrelease();
				}
				keys[i].pressed = false;
				keys[i].held = false;
			}
		}
		
		
		
		//~30 fps
		console::sleep(33);
		child->update();
		
		child->onFrame();
		
		console::write(fb, cb, getCount());
		
		child->onClear();
	}
}

