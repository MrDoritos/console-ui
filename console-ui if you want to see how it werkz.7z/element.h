#pragma once
#include <vector>
#include "eventHandler.h"
#include "framebuffer.h"

struct screen;

struct element : public framebuffer {
	element(screen* scr)
		:framebuffer(scr)
	{
		this->screen = scr;
	}
	
	void update();
	void keypress();
	void keyheld();
	void keyrelease();
	void create();
	void resize();
	void onFrame();
	void onClear();
	void close();
	void focus();
	void add(element* element);
	
	
	eventHandler handler;
	//framebuffer buffer; //Should deconstruct and clean up memory for us
	std::vector<element*> children;
	screen* screen;
	bool closed;
	bool focused;
	bool trapArrowKeys;
};